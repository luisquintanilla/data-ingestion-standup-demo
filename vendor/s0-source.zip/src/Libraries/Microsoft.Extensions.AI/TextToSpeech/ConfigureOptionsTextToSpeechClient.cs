﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Shared.DiagnosticIds;
using Microsoft.Shared.Diagnostics;

namespace Microsoft.Extensions.AI;

/// <summary>Represents a delegating text to speech client that configures a <see cref="TextToSpeechOptions"/> instance used by the remainder of the pipeline.</summary>
[Experimental(DiagnosticIds.Experiments.AITextToSpeech, UrlFormat = DiagnosticIds.UrlFormat)]
public sealed class ConfigureOptionsTextToSpeechClient : DelegatingTextToSpeechClient
{
    /// <summary>The callback delegate used to configure options.</summary>
    private readonly Action<TextToSpeechOptions> _configureOptions;

    /// <summary>Initializes a new instance of the <see cref="ConfigureOptionsTextToSpeechClient"/> class with the specified <paramref name="configure"/> callback.</summary>
    /// <param name="innerClient">The inner client.</param>
    /// <param name="configure">
    /// The delegate to invoke to configure the <see cref="TextToSpeechOptions"/> instance. It is passed a clone of the caller-supplied <see cref="TextToSpeechOptions"/> instance
    /// (or a newly constructed instance if the caller-supplied instance is <see langword="null"/>).
    /// </param>
    /// <remarks>
    /// The <paramref name="configure"/> delegate is passed either a new instance of <see cref="TextToSpeechOptions"/> if
    /// the caller didn't supply a <see cref="TextToSpeechOptions"/> instance, or a clone (via <see cref="TextToSpeechOptions.Clone"/> of the caller-supplied
    /// instance if one was supplied.
    /// </remarks>
    public ConfigureOptionsTextToSpeechClient(ITextToSpeechClient innerClient, Action<TextToSpeechOptions> configure)
        : base(innerClient)
    {
        _configureOptions = Throw.IfNull(configure);
    }

    /// <inheritdoc/>
    public override async Task<TextToSpeechResponse> GetAudioAsync(
        string text, TextToSpeechOptions? options = null, CancellationToken cancellationToken = default)
    {
        return await base.GetAudioAsync(text, Configure(options), cancellationToken);
    }

    /// <inheritdoc/>
    public override async IAsyncEnumerable<TextToSpeechResponseUpdate> GetStreamingAudioAsync(
        string text, TextToSpeechOptions? options = null, [EnumeratorCancellation] CancellationToken cancellationToken = default)
    {
        await foreach (var update in base.GetStreamingAudioAsync(text, Configure(options), cancellationToken))
        {
            yield return update;
        }
    }

    /// <summary>Creates and configures the <see cref="TextToSpeechOptions"/> to pass along to the inner client.</summary>
    private TextToSpeechOptions Configure(TextToSpeechOptions? options)
    {
        options = options?.Clone() ?? new();

        _configureOptions(options);

        return options;
    }
}
