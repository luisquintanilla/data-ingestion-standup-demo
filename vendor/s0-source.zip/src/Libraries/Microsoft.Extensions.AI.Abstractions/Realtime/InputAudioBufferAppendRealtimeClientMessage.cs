// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

using System;
using System.Diagnostics.CodeAnalysis;
using Microsoft.Shared.DiagnosticIds;
using Microsoft.Shared.Diagnostics;

namespace Microsoft.Extensions.AI;

/// <summary>
/// Represents a real-time message for appending audio buffer input.
/// </summary>
[Experimental(DiagnosticIds.Experiments.AIRealTime, UrlFormat = DiagnosticIds.UrlFormat)]
public class InputAudioBufferAppendRealtimeClientMessage : RealtimeClientMessage
{
    private DataContent _content;

    /// <summary>
    /// Initializes a new instance of the <see cref="InputAudioBufferAppendRealtimeClientMessage"/> class.
    /// </summary>
    /// <param name="audioContent">The data content containing the audio buffer data to append.</param>
    /// <exception cref="ArgumentNullException"><paramref name="audioContent"/> is <see langword="null"/>.</exception>
    public InputAudioBufferAppendRealtimeClientMessage(DataContent audioContent)
    {
        _content = Throw.IfNull(audioContent);
    }

    /// <summary>
    /// Gets or sets the audio content to append to the model audio buffer.
    /// </summary>
    /// <remarks>
    /// The content should include the audio buffer data that needs to be appended to the input audio buffer.
    /// </remarks>
    /// <exception cref="ArgumentNullException"><paramref name="value"/> is <see langword="null"/>.</exception>
    public DataContent Content
    {
        get => _content;
        set => _content = Throw.IfNull(value);
    }
}
